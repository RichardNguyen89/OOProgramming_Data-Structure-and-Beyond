/**
 * 
 */
package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Stack;

/**
 * @author Your name here.
 * 
 * For the warm up assignment, you must implement your Graph in a class
 * named CapGraph.  Here is the stub file.
 *
 */
public class CapGraph implements Graph {
	private HashMap<Integer, HashSet<Integer>> cMap = new HashMap <>();
	/* (non-Javadoc)
	 * @see graph.Graph#addVertex(int)
	 */
	@Override
	public void addVertex(int num) {
		if(!cMap.containsKey(num)) {
			cMap.put(num, new HashSet<Integer>());
		}
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see graph.Graph#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) {
		// TODO Auto-generated method stub
		if (cMap.containsKey(from) && cMap.containsKey(to)) {
			cMap.get(from).add(to);
		}
	}

	/* (non-Javadoc)
	 * @see graph.Graph#getEgonet(int)
	 */
	@Override
	public Graph getEgonet(int center) {
		// TODO Auto-generated method stub
		
		//pseudo code first
		// it will return a cMap of center and friends and edges connect those friends as well
		// create a new cMap
		Graph egoNet = new CapGraph();
		// addVertex(center)
		egoNet.addVertex(center);
		// for each of the friend, add them and the edge connect to center to the graph
		// take out the common friends and add them and the edges to the graph. 
		// Check the 
		for (int f1: cMap.get(center)) {
			egoNet.addVertex(f1);
			egoNet.addEdge(center, f1);
			List<Integer> common = new ArrayList<>(cMap.get(f1));
			common.retainAll(cMap.get(center));
			
			for (int f2: common) {
				egoNet.addVertex(f2);
				egoNet.addEdge(f1, f2);
			}
			
			if (cMap.get(f1).contains(center)) {// the above common will exclude the center. Therefore, need to check this case as well
				egoNet.addEdge(f1, center);
			}
		}
		
	return egoNet;
	}

	public Graph reverseEdges (HashMap<Integer, HashSet<Integer>> map) {
		Graph rG = new CapGraph();
		for (int n : map.keySet()) {
			rG.addVertex(n);
			for (int j : map.get(n)) {
				rG.addVertex(j);
				//rG.exportGraph().get(j).add(n); //because this is a directed graph, sometimes the original has n--> j but not j-->n. when reverse, need to make sure add n so that can form j-->n
				rG.addEdge(j, n);
			}
		}
		
		
	return rG;	
	}
	/* (non-Javadoc)
	 * @see graph.Graph#getSCCs()
	 */
	@Override
	public List<Graph> getSCCs() {
		// TODO Auto-generated method stub
		List<Graph> SCCs = new ArrayList<>();
		Stack<Integer> start = new Stack<>();
		start.addAll(cMap.keySet());
		// DFS first time. keep track of the order
		Stack<Integer> finishedOrder = DFS.DFS(this, start);
		//System.out.print(finishedOrder);	
		// reverse the graph
		Graph reverse = reverseEdges(cMap);
		
		// dfs the second time on the reverse graph based on the finished order
		//Stack<Integer> fnal = DFS.DFS(reverse, finishedOrder);
		
		HashSet<Integer> visited = new HashSet<>();
		Stack<Integer> finished = new Stack<>();
		
		while (!finishedOrder.isEmpty()) {
			int temp = finishedOrder.pop();
			if (!visited.contains(temp)) {
				DFS.DFSVisit(reverse, temp, visited, finished);
				if (finished.size()>0) {
					Graph tempGraph = new CapGraph();
					for (int n : finished) {
						tempGraph.addVertex(n);
					}
					finished = new Stack<>();
					SCCs.add(tempGraph);
				}
			}
		}
		
		// return a list of SCC
		
		return SCCs;
	}

	/* (non-Javadoc)
	 * @see graph.Graph#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		// TODO Auto-generated method stub
		return new HashMap <>(cMap);
	}

}
